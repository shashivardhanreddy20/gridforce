import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  RefreshControl,
  Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Location from 'expo-location';
import {
  requestLocationPermissions,
  requestNotificationPermissions,
  getCurrentLocation,
  isWithinGeofence,
  startLocationWatching,
  sendNotification,
  DWELL_TIME_MS,
} from '../utils/geofence';
import {
  getStores,
  generateRecommendation,
  getUserRecommendations,
} from '../utils/api';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function Index() {
  const [locationEnabled, setLocationEnabled] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<{
    latitude: number;
    longitude: number;
  } | null>(null);
  const [stores, setStores] = useState<any[]>([]);
  const [nearbyStores, setNearbyStores] = useState<any[]>([]);
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [locationSubscription, setLocationSubscription] = useState<any>(null);
  const [dwellTimes, setDwellTimes] = useState<Record<string, number>>({});
  const [testMode, setTestMode] = useState(false);
  const [testLat, setTestLat] = useState('37.7749');
  const [testLon, setTestLon] = useState('-122.4194');
  const [showTestPanel, setShowTestPanel] = useState(false);

  useEffect(() => {
    initializeApp();
    return () => {
      if (locationSubscription) {
        locationSubscription.remove();
      }
    };
  }, []);

  useEffect(() => {
    if (currentLocation && stores.length > 0) {
      checkNearbyStores();
    }
  }, [currentLocation, stores]);

  useEffect(() => {
    if (testMode) {
      // Override location with test coordinates
      const lat = parseFloat(testLat);
      const lon = parseFloat(testLon);
      if (!isNaN(lat) && !isNaN(lon)) {
        setCurrentLocation({ latitude: lat, longitude: lon });
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [testMode]);

  const initializeApp = async () => {
    try {
      // Get or create user ID
      let storedUserId = await AsyncStorage.getItem('userId');
      if (!storedUserId) {
        storedUserId = `user_${Date.now()}`;
        await AsyncStorage.setItem('userId', storedUserId);
      }
      setUserId(storedUserId);

      // Request permissions
      const locationGranted = await requestLocationPermissions();
      const notificationGranted = await requestNotificationPermissions();

      if (!locationGranted) {
        Alert.alert(
          'Location Required',
          'Please enable location permissions to receive personalized offers.'
        );
        return;
      }

      setLocationEnabled(true);

      // Get initial location
      const location = await getCurrentLocation();
      if (location) {
        setCurrentLocation(location);
      }

      // Start watching location
      const subscription = await startLocationWatching((loc) => {
        setCurrentLocation({
          latitude: loc.coords.latitude,
          longitude: loc.coords.longitude,
        });
      });
      setLocationSubscription(subscription);

      // Load stores
      await loadStores();

      // Load recommendations
      if (storedUserId) {
        await loadRecommendations(storedUserId);
      }
    } catch (error) {
      console.error('Initialization error:', error);
    }
  };

  const loadStores = async () => {
    try {
      const storesData = await getStores();
      setStores(storesData);
    } catch (error) {
      console.error('Error loading stores:', error);
    }
  };

  const loadRecommendations = async (uid: string) => {
    try {
      const recs = await getUserRecommendations(uid);
      setRecommendations(recs);
    } catch (error) {
      console.error('Error loading recommendations:', error);
    }
  };

  const checkNearbyStores = () => {
    if (!currentLocation) return;

    const nearby = stores.filter((store) =>
      isWithinGeofence(
        currentLocation.latitude,
        currentLocation.longitude,
        store.latitude,
        store.longitude,
        store.radius
      )
    );

    setNearbyStores(nearby);

    // Check dwell time for nearby stores
    nearby.forEach((store) => {
      const now = Date.now();
      const enterTime = dwellTimes[store.id] || now;
      const dwellTime = now - enterTime;

      // If just entered, record time
      if (!dwellTimes[store.id]) {
        setDwellTimes((prev) => ({ ...prev, [store.id]: now }));
      }

      // If dwell time met, trigger recommendation
      if (dwellTime >= DWELL_TIME_MS && userId) {
        triggerRecommendation(store);
        // Reset dwell time
        setDwellTimes((prev) => ({ ...prev, [store.id]: 0 }));
      }
    });
  };

  const triggerRecommendation = async (store: any) => {
    if (!userId || !currentLocation) return;

    try {
      setLoading(true);
      const recommendation = await generateRecommendation({
        user_id: userId,
        store_id: store.id,
        latitude: currentLocation.latitude,
        longitude: currentLocation.longitude,
      });

      // Show notification
      await sendNotification(
        `Special Offer at ${store.name}!`,
        'Tap to see your personalized deal',
        recommendation
      );

      // Reload recommendations
      await loadRecommendations(userId);
    } catch (error: any) {
      console.error('Error generating recommendation:', error);
      Alert.alert('Error', error.message || 'Failed to generate recommendation');
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadStores();
    if (userId) {
      await loadRecommendations(userId);
    }
    setRefreshing(false);
  };

  const parseRecommendation = (rec: any) => {
    try {
      const text = rec.recommendation || '';
      const offerMatch = text.match(/OFFER:\s*(.+?)(?:\n|DISCOUNT:)/i);
      const discountMatch = text.match(/DISCOUNT:\s*(.+?)(?:\n|MESSAGE:)/i);
      const messageMatch = text.match(/MESSAGE:\s*(.+?)$/i);

      return {
        offer: offerMatch ? offerMatch[1].trim() : 'Special offer available',
        discount: discountMatch ? discountMatch[1].trim() : 'Limited time deal',
        message: messageMatch ? messageMatch[1].trim() : text,
      };
    } catch {
      return {
        offer: 'Personalized offer',
        discount: 'Great savings',
        message: rec.recommendation,
      };
    }
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.contentContainer}
      refreshControl={
        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
      }>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <Ionicons name="bulb" size={32} color="#6366f1" />
          <Text style={styles.headerTitle}>Edge Brain AI</Text>
        </View>
        <Text style={styles.headerSubtitle}>
          Multi-Agent Location Intelligence
        </Text>
      </View>

      {/* Test Mode Panel */}
      <TouchableOpacity
        style={styles.testModeButton}
        onPress={() => setShowTestPanel(!showTestPanel)}>
        <Ionicons name="flask" size={20} color="#f59e0b" />
        <Text style={styles.testModeButtonText}>
          {showTestPanel ? 'Hide' : 'Show'} Test Mode
        </Text>
      </TouchableOpacity>

      {showTestPanel && (
        <View style={styles.testPanel}>
          <View style={styles.testPanelHeader}>
            <Ionicons name="construct" size={20} color="#f59e0b" />
            <Text style={styles.testPanelTitle}>Location Override</Text>
          </View>
          
          <View style={styles.toggleRow}>
            <Text style={styles.toggleLabel}>Test Mode:</Text>
            <TouchableOpacity
              style={[styles.toggle, testMode && styles.toggleActive]}
              onPress={() => {
                try {
                  setTestMode(!testMode);
                } catch (error) {
                  console.error('Toggle error:', error);
                  Alert.alert('Error', 'Failed to toggle test mode');
                }
              }}>
              <View style={[styles.toggleCircle, testMode && styles.toggleCircleActive]} />
            </TouchableOpacity>
          </View>

          {testMode && (
            <>
              <Text style={styles.inputLabel}>Test Latitude</Text>
              <TextInput
                style={styles.input}
                value={testLat}
                onChangeText={setTestLat}
                placeholder="37.7749"
                placeholderTextColor="#64748b"
                keyboardType="numeric"
              />

              <Text style={styles.inputLabel}>Test Longitude</Text>
              <TextInput
                style={styles.input}
                value={testLon}
                onChangeText={setTestLon}
                placeholder="-122.4194"
                placeholderTextColor="#64748b"
                keyboardType="numeric"
              />

              <TouchableOpacity
                style={styles.applyButton}
                onPress={() => {
                  const lat = parseFloat(testLat);
                  const lon = parseFloat(testLon);
                  if (!isNaN(lat) && !isNaN(lon)) {
                    setCurrentLocation({ latitude: lat, longitude: lon });
                    Alert.alert('Success', 'Test location applied!');
                  }
                }}>
                <Text style={styles.applyButtonText}>Apply Location</Text>
              </TouchableOpacity>

              <View style={styles.quickButtons}>
                <TouchableOpacity
                  style={styles.quickButton}
                  onPress={() => {
                    setTestLat('37.7749');
                    setTestLon('-122.4194');
                  }}>
                  <Text style={styles.quickButtonText}>SF</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.quickButton}
                  onPress={() => {
                    setTestLat('40.7128');
                    setTestLon('-74.0060');
                  }}>
                  <Text style={styles.quickButtonText}>NYC</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.quickButton}
                  onPress={() => {
                    setTestLat('34.0522');
                    setTestLon('-118.2437');
                  }}>
                  <Text style={styles.quickButtonText}>LA</Text>
                </TouchableOpacity>
              </View>
            </>
          )}
        </View>
      )}

      {/* Location Status */}
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <Ionicons
            name={locationEnabled ? 'location' : 'location-outline'}
            size={24}
            color={locationEnabled ? '#10b981' : '#ef4444'}
          />
          <Text style={styles.cardTitle}>Location Status</Text>
          {testMode && (
            <View style={styles.testBadge}>
              <Text style={styles.testBadgeText}>TEST MODE</Text>
            </View>
          )}
        </View>
        <Text style={styles.cardContent}>
          {locationEnabled
            ? currentLocation
              ? `${currentLocation.latitude.toFixed(4)}, ${currentLocation.longitude.toFixed(
                  4
                )}`
              : 'Getting location...'
            : 'Location disabled'}
        </Text>
        {nearbyStores.length > 0 && (
          <View style={styles.badge}>
            <Text style={styles.badgeText}>
              {nearbyStores.length} store{nearbyStores.length > 1 ? 's' : ''} nearby
            </Text>
          </View>
        )}
      </View>

      {/* Nearby Stores */}
      {nearbyStores.length > 0 && (
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Ionicons name="storefront" size={24} color="#f59e0b" />
            <Text style={styles.cardTitle}>Nearby Stores</Text>
          </View>
          {nearbyStores.map((store) => (
            <View key={store.id} style={styles.storeItem}>
              <Text style={styles.storeName}>{store.name}</Text>
              <Text style={styles.storeDistance}>
                Within {store.radius}m radius
              </Text>
            </View>
          ))}
        </View>
      )}

      {/* Latest Recommendations */}
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <Ionicons name="gift" size={24} color="#ec4899" />
          <Text style={styles.cardTitle}>Your Offers</Text>
        </View>
        
        {/* Always show Test AI button */}
        <TouchableOpacity
          style={styles.testAiButton}
          onPress={async () => {
            if (!userId) {
              Alert.alert('Setup Required', 'Please create your profile in Profile tab first');
              return;
            }
            if (stores.length === 0) {
              Alert.alert('Setup Required', 'Please create a store in Setup tab first');
              return;
            }
            setLoading(true);
            try {
              const testLocation = currentLocation || { latitude: 37.7749, longitude: -122.4194 };
              const store = stores[0];
              const rec = await generateRecommendation({
                user_id: userId,
                store_id: store.id,
                latitude: testLocation.latitude,
                longitude: testLocation.longitude,
              });
              await loadRecommendations(userId);
              Alert.alert('Success! 🎉', 'AI generated your personalized offer! Scroll down to see it.');
            } catch (error: any) {
              console.error('Test AI error:', error);
              Alert.alert('Error', error.message || 'Failed to generate recommendation. Please check Setup tab has stores & inventory.');
            } finally {
              setLoading(false);
            }
          }}>
          <Ionicons name="flash" size={18} color="#fff" />
          <Text style={styles.testAiButtonText}>Generate AI Offer Now</Text>
        </TouchableOpacity>

        {loading ? (
          <ActivityIndicator size="large" color="#6366f1" style={styles.loader} />
        ) : recommendations.length > 0 ? (
          recommendations.slice(0, 3).map((rec) => {
            const parsed = parseRecommendation(rec);
            return (
              <View key={rec.id} style={styles.recommendationCard}>
                <Text style={styles.offerTitle}>{parsed.offer}</Text>
                <View style={styles.discountBadge}>
                  <Text style={styles.discountText}>{parsed.discount}</Text>
                </View>
                <Text style={styles.offerMessage}>{parsed.message}</Text>
                <Text style={styles.offerTime}>
                  {new Date(rec.created_at).toLocaleString()}
                </Text>
              </View>
            );
          })
        ) : (
          <Text style={styles.emptyText}>
            No offers yet. Click "Generate AI Offer Now" button above!
          </Text>
        )}
      </View>

      {/* Stats */}
      <View style={styles.statsContainer}>
        <View style={styles.statBox}>
          <Text style={styles.statNumber}>{stores.length}</Text>
          <Text style={styles.statLabel}>Total Stores</Text>
        </View>
        <View style={styles.statBox}>
          <Text style={styles.statNumber}>{recommendations.length}</Text>
          <Text style={styles.statLabel}>Offers Received</Text>
        </View>
        <View style={styles.statBox}>
          <Text style={styles.statNumber}>3</Text>
          <Text style={styles.statLabel}>AI Agents</Text>
        </View>
      </View>

      {/* Info */}
      <View style={styles.infoCard}>
        <Ionicons name="information-circle" size={20} color="#3b82f6" />
        <Text style={styles.infoText}>
          Stay near a store for 10 seconds to trigger AI recommendation
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
  },
  contentContainer: {
    padding: 16,
    paddingBottom: 32,
  },
  header: {
    marginBottom: 24,
    paddingVertical: 16,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 8,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
  },
  headerSubtitle: {
    fontSize: 14,
    color: '#94a3b8',
    marginLeft: 44,
  },
  card: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#334155',
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
  },
  cardContent: {
    fontSize: 14,
    color: '#cbd5e1',
    fontFamily: Platform.OS === 'ios' ? 'Courier' : 'monospace',
  },
  badge: {
    backgroundColor: '#10b981',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    alignSelf: 'flex-start',
    marginTop: 12,
  },
  badgeText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '600',
  },
  storeItem: {
    paddingVertical: 8,
    borderTopWidth: 1,
    borderTopColor: '#334155',
    marginTop: 8,
  },
  storeName: {
    fontSize: 16,
    fontWeight: '500',
    color: '#fff',
    marginBottom: 4,
  },
  storeDistance: {
    fontSize: 12,
    color: '#94a3b8',
  },
  loader: {
    marginVertical: 20,
  },
  recommendationCard: {
    backgroundColor: '#2d3748',
    borderRadius: 8,
    padding: 12,
    marginTop: 8,
    borderLeftWidth: 4,
    borderLeftColor: '#ec4899',
  },
  offerTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 8,
  },
  discountBadge: {
    backgroundColor: '#ec4899',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    alignSelf: 'flex-start',
    marginBottom: 8,
  },
  discountText: {
    color: '#fff',
    fontSize: 11,
    fontWeight: '700',
  },
  offerMessage: {
    fontSize: 14,
    color: '#cbd5e1',
    marginBottom: 8,
    lineHeight: 20,
  },
  offerTime: {
    fontSize: 11,
    color: '#64748b',
  },
  emptyText: {
    fontSize: 14,
    color: '#64748b',
    fontStyle: 'italic',
    textAlign: 'center',
    paddingVertical: 16,
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  statBox: {
    flex: 1,
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#334155',
  },
  statNumber: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#6366f1',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: '#94a3b8',
    textAlign: 'center',
  },
  infoCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#1e3a5f',
    borderRadius: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: '#3b82f6',
  },
  infoText: {
    flex: 1,
    fontSize: 13,
    color: '#93c5fd',
    lineHeight: 18,
  },
  testModeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#1e293b',
    borderRadius: 8,
    padding: 12,
    marginBottom: 16,
    borderWidth: 2,
    borderColor: '#f59e0b',
  },
  testModeButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#f59e0b',
  },
  testPanel: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    borderWidth: 2,
    borderColor: '#f59e0b',
  },
  testPanelHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  testPanelTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#f59e0b',
  },
  toggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  toggleLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#cbd5e1',
  },
  toggle: {
    width: 50,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#475569',
    padding: 2,
    justifyContent: 'center',
  },
  toggleActive: {
    backgroundColor: '#10b981',
  },
  toggleCircle: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#fff',
  },
  toggleCircleActive: {
    alignSelf: 'flex-end',
  },
  inputLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: '#94a3b8',
    marginBottom: 6,
    marginTop: 8,
  },
  input: {
    backgroundColor: '#0f172a',
    borderRadius: 6,
    padding: 10,
    fontSize: 14,
    color: '#fff',
    borderWidth: 1,
    borderColor: '#334155',
  },
  applyButton: {
    backgroundColor: '#f59e0b',
    borderRadius: 6,
    padding: 10,
    alignItems: 'center',
    marginTop: 12,
  },
  applyButtonText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#000',
  },
  quickButtons: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 12,
  },
  quickButton: {
    flex: 1,
    backgroundColor: '#0f172a',
    borderRadius: 6,
    padding: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#f59e0b',
  },
  quickButtonText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#f59e0b',
  },
  testBadge: {
    backgroundColor: '#f59e0b',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 4,
    marginLeft: 8,
  },
  testBadgeText: {
    fontSize: 10,
    fontWeight: '700',
    color: '#000',
  },
  testAiButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#ec4899',
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderRadius: 10,
    marginVertical: 12,
    shadowColor: '#ec4899',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  testAiButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#fff',
  },
});

