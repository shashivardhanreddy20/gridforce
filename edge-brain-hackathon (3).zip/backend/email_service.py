# Email Sending Service for Edge Brain AI
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional
import os
from dotenv import load_dotenv

load_dotenv()

# Email configuration
SMTP_SERVER = os.getenv("SMTP_SERVER", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SENDER_EMAIL = os.getenv("SENDER_EMAIL", "edgebrain@example.com")
SENDER_PASSWORD = os.getenv("SENDER_PASSWORD", "")
SENDER_NAME = os.getenv("SENDER_NAME", "Edge Brain AI")


def send_offer_email(
    recipient_email: str,
    recipient_name: str,
    store_name: str,
    offer_text: str,
    user_analysis: str,
    inventory_analysis: str
) -> bool:
    """
    Send personalized offer email to user
    """
    try:
        # Parse the offer
        lines = offer_text.split('\n')
        offer_line = ""
        discount_line = ""
        message_line = ""
        
        for line in lines:
            if line.startswith("OFFER:"):
                offer_line = line.replace("OFFER:", "").strip()
            elif line.startswith("DISCOUNT:"):
                discount_line = line.replace("DISCOUNT:", "").strip()
            elif line.startswith("MESSAGE:"):
                message_line = line.replace("MESSAGE:", "").strip()
        
        # Create HTML email
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    line-height: 1.6;
                    color: #333;
                }}
                .container {{
                    max-width: 600px;
                    margin: 0 auto;
                    padding: 20px;
                    background-color: #f4f4f4;
                }}
                .card {{
                    background: white;
                    padding: 30px;
                    border-radius: 10px;
                    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
                }}
                .header {{
                    text-align: center;
                    color: #6366f1;
                    margin-bottom: 20px;
                }}
                .offer-box {{
                    background: linear-gradient(135deg, #6366f1 0%, #ec4899 100%);
                    color: white;
                    padding: 20px;
                    border-radius: 8px;
                    margin: 20px 0;
                    text-align: center;
                }}
                .discount-badge {{
                    background: #10b981;
                    color: white;
                    padding: 10px 20px;
                    border-radius: 20px;
                    display: inline-block;
                    margin: 10px 0;
                    font-weight: bold;
                }}
                .message {{
                    font-size: 16px;
                    margin: 20px 0;
                    text-align: center;
                }}
                .footer {{
                    text-align: center;
                    margin-top: 30px;
                    color: #666;
                    font-size: 12px;
                }}
                .location {{
                    background: #f0f9ff;
                    padding: 15px;
                    border-radius: 8px;
                    margin-top: 20px;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="card">
                    <h1 class="header">🎁 Special Offer Just For You!</h1>
                    
                    <p>Hi <strong>{recipient_name}</strong>,</p>
                    
                    <p>We noticed you're near <strong>{store_name}</strong>! Based on your preferences and purchase history, we have a personalized offer just for you:</p>
                    
                    <div class="offer-box">
                        <h2 style="margin: 0 0 15px 0;">✨ {offer_line}</h2>
                        <div class="discount-badge">🔥 {discount_line}</div>
                    </div>
                    
                    <div class="message">
                        <p><em>"{message_line}"</em></p>
                    </div>
                    
                    <div class="location">
                        <h3 style="color: #6366f1; margin-top: 0;">📍 How to Redeem:</h3>
                        <p>Visit <strong>{store_name}</strong> and show this email at checkout to claim your exclusive offer!</p>
                        <p><strong>⏰ Offer valid for today only!</strong></p>
                    </div>
                    
                    <div class="footer">
                        <p>This offer was personalized using AI based on your preferences and our current inventory.</p>
                        <p style="color: #999; font-size: 10px;">Powered by Edge Brain AI - Multi-Agent Recommendation System</p>
                    </div>
                </div>
            </div>
        </body>
        </html>
        """
        
        # Create message
        message = MIMEMultipart("alternative")
        message["Subject"] = f"🎁 Exclusive Offer at {store_name}!"
        message["From"] = f"{SENDER_NAME} <{SENDER_EMAIL}>"
        message["To"] = recipient_email
        
        # Add HTML content
        html_part = MIMEText(html_content, "html")
        message.attach(html_part)
        
        # Send email
        if SENDER_PASSWORD:  # Only send if credentials are configured
            with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
                server.starttls()
                server.login(SENDER_EMAIL, SENDER_PASSWORD)
                server.send_message(message)
            print(f"✅ Email sent to {recipient_email}")
            return True
        else:
            print(f"⚠️  Email not configured. Would send to: {recipient_email}")
            print(f"   Offer: {offer_line}")
            print(f"   Discount: {discount_line}")
            return False
            
    except Exception as e:
        print(f"❌ Error sending email: {e}")
        return False


def send_welcome_email(recipient_email: str, recipient_name: str) -> bool:
    """
    Send welcome email when user registers
    """
    try:
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                .container {{ max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f4f4f4; }}
                .card {{ background: white; padding: 30px; border-radius: 10px; }}
                .header {{ text-align: center; color: #6366f1; }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="card">
                    <h1 class="header">🎉 Welcome to Edge Brain AI!</h1>
                    <p>Hi <strong>{recipient_name}</strong>,</p>
                    <p>Thank you for joining Edge Brain! We'll send you personalized offers when you visit our partner stores.</p>
                    <p>Our AI analyzes your preferences and past purchases to create deals you'll actually love!</p>
                    <p style="text-align: center; margin-top: 30px;">
                        <strong>Happy Shopping! 🛍️</strong>
                    </p>
                </div>
            </div>
        </body>
        </html>
        """
        
        message = MIMEMultipart("alternative")
        message["Subject"] = "🎉 Welcome to Edge Brain AI!"
        message["From"] = f"{SENDER_NAME} <{SENDER_EMAIL}>"
        message["To"] = recipient_email
        message.attach(MIMEText(html_content, "html"))
        
        if SENDER_PASSWORD:
            with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
                server.starttls()
                server.login(SENDER_EMAIL, SENDER_PASSWORD)
                server.send_message(message)
            return True
        else:
            print(f"⚠️  Would send welcome email to: {recipient_email}")
            return False
            
    except Exception as e:
        print(f"❌ Error sending welcome email: {e}")
        return False
