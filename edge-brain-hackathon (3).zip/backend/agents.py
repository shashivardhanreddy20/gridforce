"""
Multi-Agent AI System for Location-Based Recommendations
Uses LangGraph to orchestrate 3 specialized AI agents in a negotiation loop

**IMPORTANT: CURRENTLY MOCKED DUE TO GOOGLE API QUOTA EXHAUSTION**
The system architecture is correct but using mock responses until quota resets.
"""
from typing import TypedDict, Annotated, List, Dict, Any
from langgraph.graph import StateGraph, END
from langchain_google_genai import ChatGoogleGenerativeAI
from datetime import datetime
import os
from dotenv import load_dotenv

load_dotenv()

# Initialize Gemini 1.5 Flash (lower resource usage)
llm = ChatGoogleGenerativeAI(
    model="gemini-1.5-flash",
    google_api_key=os.getenv("GOOGLE_API_KEY"),
    temperature=0.7
)

# Define the state that flows through agents
class AgentState(TypedDict):
    user_id: str
    user_preferences: Dict[str, Any]
    user_purchase_history: List[Dict[str, Any]]
    store_inventory: List[Dict[str, Any]]
    user_profile_analysis: str
    inventory_analysis: str
    final_recommendation: str
    messages: List[str]


def user_profiler_agent(state: AgentState) -> AgentState:
    """
    Agent 1: User Profiler
    Analyzes user preferences and purchase history to understand their likes
    
    **CURRENTLY MOCKED** - Google API quota exhausted
    """
    user_prefs = state.get("user_preferences", {})
    purchase_history = state.get("user_purchase_history", [])
    
    # MOCK RESPONSE - Replace with real LLM call when quota restored
    try:
        # Build analysis prompt
        prompt = f"""You are a User Profiler AI agent. Analyze this user's preferences and purchase history.

User Preferences: {user_prefs}
Purchase History (last 5): {purchase_history[-5:] if purchase_history else 'No history yet'}

Provide a concise analysis:
1. What are their favorite product categories?
2. What price range do they prefer?
3. Any patterns in their purchases?
4. What products would they likely be interested in?

Keep your analysis to 3-4 sentences."""
        
        response = llm.invoke(prompt)
        analysis = response.content
    except Exception as e:
        # MOCK FALLBACK when API quota exhausted
        fav_cats = user_prefs.get("favorite_categories", ["coffee"])
        price_range = user_prefs.get("price_range", "medium")
        
        analysis = f"**MOCK RESPONSE** - User shows strong preference for {', '.join(fav_cats)} with {price_range} price range. Purchase history indicates consistent buying behavior in preferred categories. Would likely be interested in premium versions of favorite items or related products with discount offers."
    
    state["user_profile_analysis"] = analysis
    state["messages"].append(f"User Profiler: {analysis}")
    
    return state


def store_inventory_agent(state: AgentState) -> AgentState:
    """
    Agent 2: Store Inventory Manager
    Analyzes current inventory status, identifies overstock and items near expiry
    
    **CURRENTLY MOCKED** - Google API quota exhausted
    """
    inventory = state.get("store_inventory", [])
    
    # MOCK RESPONSE - Replace with real LLM call when quota restored
    try:
        # Build inventory analysis prompt
        prompt = f"""You are a Store Inventory Management AI agent. Analyze this store's current inventory.

Current Inventory: {inventory}

Identify:
1. Which items are overstocked (quantity > 50)?
2. Which items are expiring soon (within 7 days)?
3. Which items need urgent sales to prevent loss?
4. What discount strategy would maximize profit while clearing stock?

Keep your analysis to 3-4 sentences."""
        
        response = llm.invoke(prompt)
        analysis = response.content
    except Exception as e:
        # MOCK FALLBACK when API quota exhausted
        overstock_items = [item for item in inventory if item.get("quantity", 0) > 50]
        analysis = f"**MOCK RESPONSE** - Found {len(overstock_items)} overstocked items requiring immediate attention. Items with high quantity need discount promotions. Recommend 20-40% discount on overstock items to accelerate sales and prevent waste."
    
    state["inventory_analysis"] = analysis
    state["messages"].append(f"Inventory Manager: {analysis}")
    
    return state


def recommendation_agent(state: AgentState) -> AgentState:
    """
    Agent 3: Recommendation Negotiator
    Synthesizes user preferences and inventory constraints to create optimal offer
    
    **CURRENTLY MOCKED** - Google API quota exhausted
    """
    user_analysis = state.get("user_profile_analysis", "")
    inventory_analysis = state.get("inventory_analysis", "")
    user_prefs = state.get("user_preferences", {})
    
    # MOCK RESPONSE - Replace with real LLM call when quota restored
    try:
        # Build recommendation prompt
        prompt = f"""You are a Recommendation Negotiation AI agent. Create a hyper-personalized offer.

User Profile Analysis: {user_analysis}

Store Inventory Analysis: {inventory_analysis}

User Preferences: {user_prefs}

Create a compelling offer that:
1. Matches user preferences (their favorite items)
2. Helps store clear overstock/expiring items
3. Creates a bundle deal if possible
4. Includes specific discount percentage

Format your response as:
OFFER: [Main product user wants] + [Bundle item from overstock]
DISCOUNT: [X]% off on [bundle item]
MESSAGE: [Compelling 1-2 sentence pitch to the user]

Example: "OFFER: Premium Coffee (your favorite!) + Gourmet Biscuits
DISCOUNT: 50% off on Biscuits
MESSAGE: We know you love our premium coffee! Today only, get your favorite blend and try our gourmet biscuits at 50% off - they pair perfectly together!"
"""
        
        response = llm.invoke(prompt)
        recommendation = response.content
    except Exception as e:
        # MOCK FALLBACK when API quota exhausted
        fav_cats = user_prefs.get("favorite_categories", ["coffee"])
        recommendation = f"""**MOCK RESPONSE**
OFFER: Premium {fav_cats[0].title()} + Gourmet Snacks Bundle
DISCOUNT: 30% off on bundle items
MESSAGE: Perfect match for your {fav_cats[0]} preferences! Get your favorite {fav_cats[0]} plus complementary items at 30% off - limited time offer just for you!"""
    
    state["final_recommendation"] = recommendation
    state["messages"].append(f"Recommendation Agent: {recommendation}")
    
    return state


# Build the LangGraph workflow
def create_recommendation_workflow():
    """
    Creates a state machine where agents negotiate in sequence
    """
    workflow = StateGraph(AgentState)
    
    # Add agent nodes
    workflow.add_node("user_profiler", user_profiler_agent)
    workflow.add_node("inventory_manager", store_inventory_agent)
    workflow.add_node("recommender", recommendation_agent)
    
    # Define the flow: User Profiler → Inventory Manager → Recommender
    workflow.set_entry_point("user_profiler")
    workflow.add_edge("user_profiler", "inventory_manager")
    workflow.add_edge("inventory_manager", "recommender")
    workflow.add_edge("recommender", END)
    
    return workflow.compile()


# Global workflow instance
recommendation_workflow = create_recommendation_workflow()


async def generate_recommendation(
    user_id: str,
    user_preferences: Dict[str, Any],
    user_purchase_history: List[Dict[str, Any]],
    store_inventory: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Main function to trigger the multi-agent recommendation system
    """
    initial_state: AgentState = {
        "user_id": user_id,
        "user_preferences": user_preferences,
        "user_purchase_history": user_purchase_history,
        "store_inventory": store_inventory,
        "user_profile_analysis": "",
        "inventory_analysis": "",
        "final_recommendation": "",
        "messages": []
    }
    
    # Run the workflow
    final_state = await recommendation_workflow.ainvoke(initial_state)
    
    return {
        "user_id": user_id,
        "store_id": store_inventory[0].get("store_id") if store_inventory else "unknown",  # Extract store_id from inventory
        "recommendation": final_state["final_recommendation"],
        "user_analysis": final_state["user_profile_analysis"],
        "inventory_analysis": final_state["inventory_analysis"],
        "agent_messages": final_state["messages"],
        "timestamp": datetime.utcnow().isoformat()
    }
