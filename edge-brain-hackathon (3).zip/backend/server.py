from fastapi import FastAPI, APIRouter, HTTPException
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
import uuid
from datetime import datetime, timedelta
from agents import generate_recommendation


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI(title="Edge Brain - AI Location Recommendation API")

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")


# ============= DATA MODELS =============

class UserPreferences(BaseModel):
    favorite_categories: List[str] = []
    price_range: str = "medium"  # low, medium, high
    dietary_restrictions: List[str] = []
    
class User(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    email: str
    preferences: UserPreferences = Field(default_factory=UserPreferences)
    created_at: datetime = Field(default_factory=datetime.utcnow)

class UserCreate(BaseModel):
    name: str
    email: str
    preferences: Optional[UserPreferences] = None

class PurchaseHistory(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    product_name: str
    category: str
    price: float
    purchased_at: datetime = Field(default_factory=datetime.utcnow)

class InventoryItem(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    store_id: str
    product_name: str
    category: str
    quantity: int
    price: float
    expiry_date: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)

class InventoryCreate(BaseModel):
    store_id: str
    product_name: str
    category: str
    quantity: int
    price: float
    expiry_date: Optional[datetime] = None

class Store(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    latitude: float
    longitude: float
    radius: int = 100  # geofence radius in meters
    created_at: datetime = Field(default_factory=datetime.utcnow)

class StoreCreate(BaseModel):
    name: str
    latitude: float
    longitude: float
    radius: int = 100

class RecommendationRequest(BaseModel):
    user_id: str
    store_id: str
    latitude: float
    longitude: float

class Recommendation(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    store_id: str
    recommendation: str
    user_analysis: str
    inventory_analysis: str
    agent_messages: List[str]
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ============= USER ENDPOINTS =============

@api_router.post("/users", response_model=User)
async def create_user(user: UserCreate):
    """Create a new user profile"""
    user_dict = user.dict()
    if user_dict.get("preferences") is None:
        user_dict["preferences"] = UserPreferences().dict()
    user_obj = User(**user_dict)
    await db.users.insert_one(user_obj.dict())
    return user_obj

@api_router.get("/users", response_model=List[User])
async def get_users():
    """Get all users"""
    users = await db.users.find().to_list(1000)
    return [User(**user) for user in users]

@api_router.get("/users/{user_id}", response_model=User)
async def get_user(user_id: str):
    """Get specific user by ID"""
    user = await db.users.find_one({"id": user_id})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return User(**user)

@api_router.put("/users/{user_id}/preferences")
async def update_user_preferences(user_id: str, preferences: UserPreferences):
    """Update user preferences"""
    result = await db.users.update_one(
        {"id": user_id},
        {"$set": {"preferences": preferences.dict()}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="User not found")
    return {"success": True, "message": "Preferences updated"}


# ============= PURCHASE HISTORY ENDPOINTS =============

@api_router.post("/purchases")
async def add_purchase(purchase: PurchaseHistory):
    """Add a purchase to user history"""
    await db.purchases.insert_one(purchase.dict())
    return {"success": True, "purchase_id": purchase.id}

@api_router.get("/purchases/{user_id}")
async def get_user_purchases(user_id: str, limit: int = 10):
    """Get user's purchase history"""
    purchases = await db.purchases.find({"user_id": user_id}).sort("purchased_at", -1).limit(limit).to_list(limit)
    # Convert MongoDB documents to clean dicts (remove _id)
    return [
        {k: v for k, v in purchase.items() if k != '_id'}
        for purchase in purchases
    ]


# ============= STORE ENDPOINTS =============

@api_router.post("/stores", response_model=Store)
async def create_store(store: StoreCreate):
    """Create a new store with geofence"""
    store_obj = Store(**store.dict())
    await db.stores.insert_one(store_obj.dict())
    return store_obj

@api_router.get("/stores", response_model=List[Store])
async def get_stores():
    """Get all stores"""
    stores = await db.stores.find().to_list(1000)
    return [Store(**store) for store in stores]

@api_router.get("/stores/{store_id}", response_model=Store)
async def get_store(store_id: str):
    """Get specific store"""
    store = await db.stores.find_one({"id": store_id})
    if not store:
        raise HTTPException(status_code=404, detail="Store not found")
    return Store(**store)


# ============= INVENTORY ENDPOINTS =============

@api_router.post("/inventory")
async def add_inventory(item: InventoryCreate):
    """Add inventory item to store"""
    item_obj = InventoryItem(**item.dict())
    await db.inventory.insert_one(item_obj.dict())
    return {"success": True, "item_id": item_obj.id}

@api_router.get("/inventory/{store_id}")
async def get_store_inventory(store_id: str):
    """Get all inventory for a store"""
    inventory = await db.inventory.find({"store_id": store_id}).to_list(1000)
    # Convert MongoDB documents to clean dicts (remove _id)
    return [
        {k: v for k, v in item.items() if k != '_id'}
        for item in inventory
    ]

@api_router.put("/inventory/{item_id}")
async def update_inventory(item_id: str, quantity: int):
    """Update inventory quantity"""
    result = await db.inventory.update_one(
        {"id": item_id},
        {"$set": {"quantity": quantity}}
    )
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Item not found")
    return {"success": True, "message": "Inventory updated"}


# ============= AI RECOMMENDATION ENDPOINT =============

@api_router.post("/recommendations/generate", response_model=Recommendation)
async def generate_ai_recommendation(request: RecommendationRequest):
    """
    Main endpoint: Triggers the multi-agent AI system
    Called when user enters geofence
    """
    # Get user data
    user = await db.users.find_one({"id": request.user_id})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    
    # Get user's purchase history
    purchases = await db.purchases.find({"user_id": request.user_id}).sort("purchased_at", -1).limit(10).to_list(10)
    
    # Get store inventory
    inventory = await db.inventory.find({"store_id": request.store_id}).to_list(1000)
    
    # Trigger multi-agent recommendation system
    result = await generate_recommendation(
        user_id=request.user_id,
        user_preferences=user.get("preferences", {}),
        user_purchase_history=purchases,
        store_inventory=inventory
    )
    
    # Add store_id to the result
    result["store_id"] = request.store_id
    
    # Save recommendation
    recommendation = Recommendation(**result)
    await db.recommendations.insert_one(recommendation.dict())
    
    return recommendation

@api_router.get("/recommendations/{user_id}")
async def get_user_recommendations(user_id: str, limit: int = 10):
    """Get user's past recommendations"""
    recommendations = await db.recommendations.find({"user_id": user_id}).sort("created_at", -1).limit(limit).to_list(limit)
    # Convert MongoDB documents to clean dicts (remove _id)
    return [
        {k: v for k, v in rec.items() if k != '_id'}
        for rec in recommendations
    ]


# ============= HEALTH CHECK =============

@api_router.get("/")
async def root():
    return {
        "message": "Edge Brain AI - Multi-Agent Location Recommendation System",
        "status": "running",
        "agents": ["User Profiler", "Inventory Manager", "Recommendation Negotiator"]
    }

# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
